/**
 * File: omxDLx.h
 *
 * Copyright (c) 2005-2006 The Khronos Group Inc. All Rights Reserved.
 *
 */
/*
 * Appendix A - DLx APIs
 *
 * Brief: DLx is
 * * Defined as a working group approved API extension.
 * * These APIs are not part of the DL standard but are optional extras that can be vendor specific.  They are designed and explained
 * * as part of the DL standard so that there can be some commonality among vendors and there is the possibility of 
 * * standardisation but that the standardisation is not mandatory.
 * * DLx APIs may rely on DL functions whenever possible to leverage compatibility.
 * * Working groups may also define specific DLx functions for a specification release.
 * * DLX is not guaranteed to be backward compatible with previous versions.
 */

#ifndef _OMXDLx_H_
#define _OMXDLx_H_

#include "omxtypes.h"
#ifndef _OMXIP_H_
#include "omxIP.h"
#endif
#ifndef _OMXVC_H_
#include "omxVC.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif
/******************************************************************************************/
/**
 *
 *  NewDomain: COMM The Common subdomain
 *  WithinDomain: VC
 *
 *  StartDomain: COMM
 */

/**
 * Function: omxVCCOMM_ExpandFrame_I_DLx
 *
 * Description:
 * This function expands a reconstructed frame in-place. The unexpanded source frame should be stored in a
 * plane buffer with sufficient space pre-allocated for edge expansion, and the input frame should be located
 * in the plane buffer center. This function executes the pixel expansion by replicating source frame edge
 * pixel intensities in the empty pixel locations (expansion region) between the source frame edge and the
 * plane buffer edge. The width and height of the expansion regions on each vertical and horizontal edge are
 * controlled by the parameters iExpandPelsWidth and iExpandPelsHeight, respectively.
 * Parameters:
 * [in] pSrcDstPlane - pointer to the top-left corner of the frame to be expanded; must be aligned on a
 *                     16-byte boundary.
 * [in] iFrameWidth - frame width; must be a multiple of 16.
 * [in] iFrameHeight - frame height; must be a multiple of 16.
 * [in] iExpandPelsWidth - number of pixels to be expanded in the horizontal direction on the left and
 *                          right edges; must be a multiple of 8.
 * [in] iExpandPelsHeight - number of pixels to be expanded in the vertical direction on the top and
 *                           bottom edges; must be a multiple of 8.
 * [in] iPlaneStep - distance, in bytes, between the start of consecutive lines in the plane buffer; must be
 *                          larger than or equal to (iFrameWidth + 2 * iExpandPelsWidth).
 * [out] pSrcDstPlane - Pointer to the top-left corner of the frame (NOT the top-left corner of the plane);
 *                      must be aligned on a 16-byte boundary.
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */


OMXResult omxVCCOMM_ExpandFrame_I_DLx (
	    OMX_U8  *pSrcDstPlane, 
		OMX_U32 iFrameWidth,
		OMX_U32 iFrameHeight,
		OMX_U32 iExpandPelsWidth,
		OMX_U32 iExpandPelsHeight, 
		OMX_U32 iPlaneStep);


/**
 * EndDomain: COMM
 */

/* *****************************************************************************************/
/**
 *
 *  NewDomain: M4P2 The MPEG4 Codec subdomain
 *  WithinDomain: VC
 *
 *  StartDomain: M4P2
 */


/** transparent status */

enum {
    OMX_VC_TRANSPARENT	= 0,	/** Wholly transparent */
	OMX_VC_PARTIAL		= 1,	/** Partially transparent */
	OMX_VC_OPAQUE		= 2		/** Opaque */
};


typedef struct OMXSadmultipleParam
{
	OMX_S16 Block_width;
	OMX_S16 Block_height;	
	OMX_S16 Target_width;	
	OMX_S16 ref_width;
	OMX_S16 step_horz;
	OMX_S16 step_vert;	
	OMX_S16 nsteps_horz;	
	OMX_S16 nsteps_vert;
	OMX_S16 minmax_clear;	
	OMX_S16 Minmax;
	OMX_S16 id_mode;
	OMX_S16 id_value;
	OMX_S16 Thresh;	
	OMX_S16 center_block;	
	OMX_S16 skip_field;
} OMXSadmultipleParam;

typedef struct OMXSadmultipleInterpParam
{
   OMX_S16 block_width;	
   OMX_S16 block_height;	
   OMX_S16 target_width;	
} OMXSadmultipleInterpParam;



typedef struct OMXSoSmultipleInterpParam
{
	OMX_S16 block_width;	
	OMX_S16 block_height;	
	OMX_S16 target_width;	
} OMXSoSmultipleInterpParam;

/**
 *
 * Function:  omxVCM4P2_DCT8x8blks_DLx	
 *
 * Description:  
 * performs the 2D DCT on 8x8 data blocks
 *
 * Return Value: OMXResult 
 *
 * Parameters:	
 * [in]  pBlkIn	starting address of input matrix 		16 byte aligned
 * [in]  knum_blks	number of 8x8 blocks 
 * [out] pBlkOut	starting address of output matrix 		16 byte aligned
 *
 * Brief:	This function performs the 2D DCT on 8x8 data blocks.
 */

OMXResult omxVCM4P2_DCT8x8blks_DLx (OMX_S16 *pBlkIn, OMX_S16 *pBlkOut, OMX_INT knum_blks);

/**
 *
 * Function: omxVCM4P2_IDCT8x8blks_DLx	 
 *
 * Description:  
 * performs the 2D IDCT on 8x8 data blocks
 *
 * Return Value: OMXResult
 *
 * Parameters:	
 * [in]   pBlkIn	starting address of input matrix   	16 byte aligned
 * [in]   knum_blks	number of 8x8 blocks  
 * [out]  pBlkOut	starting address of output matrix   	16 byte aligned
 *
 * Brief:	This function performs the 2D IDCT on 8x8 data blocks.
 */

OMXResult omxVCM4P2_IDCT8x8blks_DLx (OMX_S16 *pBlkIn, OMX_S16 *pBlkOut, OMX_INT knum_blks);

/**
 * Function:  omxVCM4P2_hpDiffMBY_DLx	
 *
 * Description: 
 * Performs half-pixel motion estimation and difference computation for a frame with no picture extension. 
 *		(Category: Macroblock based function)
 *
 * Return Value:  OMXResult
 *
 * Parameters:	
 * [in]  pSrcBuf	        Pointer to the current macroblock in the current frame buffer  .
 * [in]  pRefBuf          	Pointer to the best-matched macroblock in the reference frame buffer  .
 * [in]  pSrcMV         	Pointer to the best motion vector in full pixel units for the luminance vector from integer motion estimation  .
 * [in]  rndCtrl	        Round control parameter used for half-pixel interpolation  .
 * [in]  width	            Width of the luminance component of the frame  
 * [in]  fourMVmode	        Enable bit to indicate that there can be four MVs for the 16x16 macroblock  .
 * [out] pResBuf	        Pointer to the residual/error values as result of mismatch between the best-matched pixels in the reference macroblock and the current macroblock. 
 *                          This is a linear array of 256 elements  .
 * [out] pDstMV	            Pointer to the best-matched motion vectors for all the four blocks in the luminance macroblock. 
 *                          This is an array of four elements, with each element representing motion vector (in half-pixel units) for one block. 
 *                          If the macroblock has only one best matched motion vector then the best-matched motion vector is replicated to all the members of the array  .
 *
 * Brief:	This is a middle level function call that performs half-pixel motion estimation and difference computation for a frame with no picture extension. 
 */

OMXResult omxVCM4P2_hpDiffMBY_DLx (OMX_U8 *pSrcBuf, OMX_U8 *pRefBuf, OMXVCMotionVector *pSrcMV, OMX_INT rndCtrl, OMX_INT width, OMX_INT fourMVmode, OMX_S16 *pResBuf, OMXVCMotionVector **pDstMV);

/**
 * Function:  OMXVCM4P2hpDiffBlkC_DLx 	
 *
 * Description:  
 * Perform half pixel interpolation chrominance pixels (Cb) and calculate difference data. 
 *		(Category: Block based function)    
 *
 * Return Value: OMXResult
 *
 * Notes:
 * This is a super-block function. The luminance motion vector is used to determine the type of interpolation pixel (horizontal, vertical, horizontal-vertical or integer) to be calculated. The same function call can be used for H.263 encoding also.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the current macroblock in the current frame buffer  .
 * [in]  pRefBuf          	Pointer to the best-matched macroblock in the reference frame buffer  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  width	Width of the chrominance component of the frame  
 * [in]  pSrcMV	Pointer to the best-matched motion vector (in half pixel units)  . 
 * [out] pResBuf	Pointer to the residual/error values as result of mismatch between the best-matched pixels in the reference macroblock and the current macroblock. This is a linear array of 64 elements  .
 *
 * Brief:	This is a middle level function call that computes the half-pixel refinement and as well as the difference between the current block (Cb) and the computed half/integer pixels for a frame. 
 */

OMXResult omxVCM4P2_hpDiffBlkC_DLx (OMX_U8 *pSrcBuf, OMX_U8 *pRefBuf, OMX_INT rndCtrl, OMXVCMotionVector *pSrcMV, OMX_INT width, OMX_S16 *pResBuf);

/**
 * Function:  omxVCM4P2_hpDiffBlkDCTY_DLx	
 *
 * Description:
 * Perform half pixel interpolation, calculate difference data and DCT for the luminance macroblock in a frame with no picture extension. (Category: Macroblock based function)    
 *
 * Return Value:  OMXResult
 * Notes:
 * This function can also be used for H.263 encode also.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the current macroblock in the current frame buffer  .
 * [in]  pRefBuf          	Pointer to the best-matched macroblock in the reference frame buffer  .
 * [in]  pSrcMV	Pointer to the best motion vector in full pixel units for the luminance vector from integer motion estimation  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  width	Width of the chrominance component of the frame  
 * [in]  fourMVmode	Enable bit to indicate that there can be four MVs for the 16x16 macroblock. 
 * [out] pResBuf	Pointer to the DCT macroblock array. This is a linear array of 256 elements  .
 * [out] pDstMV	Pointer to the best-matched motion vectors for all the four blocks in the luminance macroblock. This is an array of four elements, with each element representing motion vector (in half-pixel units) of one block. If the macroblock has only one best matched motion vector then the best-matched motion vector is replicated to all the members of the array  .
 *
 * Brief:	This is a super-block function. This is a middle level function call that performs half-pixel motion estimation, computes difference values and performs DCT on each of the four luminance block. 
 */

OMXResult omxVCM4P2_hpDiffBlkDCTY_DLx (OMX_U8 *pSrcBuf, OMX_U8 *pRefBuf, OMXVCMotionVector *pSrcMV, OMX_INT rndCtrl, OMX_INT width, OMX_INT fourMVmode, OMX_S16 *pResBuf, OMXVCMotionVector **pDstMV);

/**
 * Function:  omxVCM4P2_hpDiffBlkDCTC_DLx	
 *
 * Description:  
 * Perform half pixel interpolation, calculate difference and apply DCT on the resultant block data. 
 *		(Category: Block based function)    
 * 
 * Return Value:  OMXResult
 *
 * Notes:
 * The same function call can be used for H.263 encoding also.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the current macroblock in the current frame buffer  .
 * [in]  pRefBuf          	Pointer to the best matched block in the chrominance reference frame  buffer  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  width	Width of the chrominance component of the frame  
 * [in]  fourMVmode	Enable bit to indicate that there can be four MVs for the 16x16 macroblock  
 * [in]  pSrcMV	Pointer to the best-matched motion vector (in half pixel units)  . 
 * [out] pResBuf	Pointer to the residual/error values as result of mismatch between the best-matched pixels in the reference macroblock and the current macroblock. This is a linear array of 64 elements  .
 *
 * Brief:	This is a super-block function. This is a middle level function call that performs half-pixel interpolation as required on the best matched chrominance (Cb/Cr), computes the difference between the current block and the computed half/integer pixels and applies DCT on the resultant for a frame. 
 */

OMXResult omxVCM4P2_hpDiffBlkDCTC_DLx (OMX_U8 *pSrcBuf, OMX_U8 *pRefBuf, OMX_INT rndCtrl, OMX_INT width, OMX_INT fourMVmode, OMXVCMotionVector *pSrcMV, OMX_S16 *pResBuf);


/**
 * Function:  omxVCM4P2_QuantACDCScanBlkIntra_DLx
 *
 * Description:  
 * Perform quantization, AC/DC prediction and scan for a block of data.
 *		(Category: Block based function)
 *
 * Return Value:  OMXResult
 * Notes:
 * This is a super-block function. The same function call can be used for H.263 encoding also. In this case, the user should set the dcScaler and quant to the same value. 
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the block  .
 * [in]  dcScaler	Quantization parameter for DC coefficient  .
 * [in]  quant	Quantization parameter for AC coefficients  .
 * [in]  acFlag	Flag indication whether AC prediction is switched on  .
 * [in]  pACDCArray	Pointer to array containing AC/DC (I/O) coefficients of previous blocks.
 * [out] numCoef	Pointer to the number of valid coefficients in the block  .
 * [out] scanDirection	Pointer to the scan lookup table  .
 * [out] pResBuf	Pointer to the linear array of scanned coefficients, where numCoef points the number of valid elements  . 
 *
 * Brief:	This is a middle level function call that performs quantization, AC/DC prediction and scanning of one intra block of coefficients. 
 */

OMXResult omxVCM4P2_QuantACDCScanBlkIntra_DLx (OMX_S16 *pSrcBuf, OMX_INT dcScaler, OMX_INT quant, OMX_INT acFlag, OMX_S16 *pACDCArray, OMX_U8 *numCoef, OMX_U8 *scanDirection, OMX_S16 *pResBuf);

/**
 * Function:  omxVCM4P2_QuantScanBlkInter_DLx	
 *
 * Description: 
 * Perform quantization, AC/DC prediction and scan for a block of data.
 *		(Category: Block based function)
 * Return Value:  The number of valid coefficients in a block.
 *
 * Notes:
 * This is a super-block function. This function can also be used in H.263 video coding. 
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the input block  .
 * [in]  quant	Quantization parameter for the block coefficients  .
 * [out] pResBuf	Pointer to the linear array of scanned coefficients, where numCoef points the number of valid elements  . 
 *
 * Brief:	This is a middle level function call that performs quantization, AC/DC prediction and scanning of a inter block of coefficients. 
 */

OMXResult omxVCM4P2_QuantScanBlkInter_DLx  (OMX_S16 *pSrcBuf, OMX_INT quant,OMX_S16 *pResBuf);

/**
 * Function:  omxVCM4P2_IQMBIntra_DLx	
 *
 * Description:  
 * Perform inverse quantization, for all the six blocks (YCbCr).
 *		(Category: Macroblock based function)
 * Return Value:  OMXResult
 * Notes:
 * This function can also be used in H.263 video coding. To use the function for H.263 baseline, set dcScaler to 8.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the inverse transformed data. This is a linear array containing all the 384 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  dcScaler	Quantization parameter for DC coefficient  .
 * [in]  quant	Quantization parameter for AC coefficients  .
 * [in]  numCoef	Pointer to the number of valid coefficients of the blocks (6) in a macroblock .
 * [out] pResBuf	Pointer to the location of resultant data  .
 *
 * Brief:	This is a middle level function call that performs inverse quantization for all the six blocks in the current macroblock.
 */

OMXResult omxVCM4P2_IQMBIntra_DLx (OMX_S16 *pSrcBuf, OMX_INT dcScaler, OMX_INT quant, OMX_U8 *numCoef, OMX_U8 *pResBuf);

/**
 * Function:  OMXResult omxVCM4P2_IQMBInter_DLx	
 *
 * Description:  
 * Perform inverse quantization of the current luminance macroblock.
 *		(Category: Macroblock based function)
 *
 * Return Value:  OMXResult
 * Notes:
 * This is a super-block function. This function can also be used in H.263 video coding.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to IDCT block data. This is a linear array containing all the 256 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  quant	Quantization parameter for AC coefficients  .
 * [out] pResBuf	Pointer to the location of the quantized data  .
 * [out] numCoef	Number of valid coefficients of the blocks (6) in a macroblock.
 *
 * Brief:	This is a middle level function call that performs inverse quantization of the current luminance macroblock. 
 */

OMX_INT omxVCM4P2_IQMBInter_DLx (OMX_S16 *pSrcBuf, OMX_INT quant, OMX_U8 *numCoef, OMX_S16 *pResBuf);


/**
 * Function:  omxVCM4P2IDCTMBIntra__DLx	
 *
 * Description:  
 * Perform inverse DCT, for all the six blocks (YCcbCr).
 *		(Category: Macroblock based function)
 *
 * Return Value:  OMXResult
 * Notes:
 * This is a super-block function. The coefficients in the input buffer are arranged in linear block wise form (i.e.) coefficients of one block (8x8) of data are succeeded by the coefficients of the next block. This function can also be used in H.263 video coding.  
 *
 * Parameters:	
 * [in]  pSrcBufY	Pointer to the inverse transformed data. This is a linear array containing all the 384 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  width	Width of the output Y frame component  .
 * [out] pResBufY	Pointer to the location of IDCT data for Y component .
 * [out] pResBufCb	Pointer to the location of IDCT data for Cb component .
 * [out] pResBufCr	Pointer to the location of IDCT data for Cr component .
 *
 * Brief:	This is a middle level function call that performs inverse DCT for all the six blocks in the current macroblock. The function can also be considered as the reconstruction step for an intra macroblock in a P-VOP.
 */

OMXResult omxVCM4P2_IDCTMBIntra_DLx (OMX_S16 *pSrcBufY, OMX_INT width, OMX_U8 *pResBufY, OMX_U8 *pResBufCb, OMX_U8 *pResBufCr);

/**
 * Function:  omxVCM4P2_IQIDCTMBIntra_DLx	   
 *
 * Description:
 * Perform inverse discrete cosine transform  and inverse quantization, for all the blocks (YCbCr) of data.
 *		(Category: Macroblock based function)
 * Return Value:  OMXResult
 * Notes:
 * In the input buffer (pSrcBuf), the coefficients of each block are assumed to be pre-processed (i.e.) every block is assumed to have 64 coefficients arranged in the normal order with the invalid coefficients assigned to zero. This function can also be used in H.263 video coding.	
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the quantized data. This is a linear array containing all the 384 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  dcScaler	Quantization parameter for DC coefficient  .
 * [in]  quant	Quantization parameter for AC coefficients  
 * [in]  width	Width of the Y component of the frame  
 * [out] pResBufY	Pointer to the location of the reconstructed buffer where the luminance data is to be written  .
 * [out] pResBufCb	Pointer to the location of the reconstructed buffer where the chrominance data (Cb) is to be written  .
 *
 * Brief:
 * This is a super-block function. This is a middle level function call that performs inverse discrete cosine transform and inverse quantization for all the six blocks in the current macroblock.
 */

OMXResult omxVCM4P2_IQIDCTMBIntra_DLx (OMX_S16 *pSrcBuf, OMX_INT dcScaler, OMX_INT quant, OMX_INT width, OMX_U8 *pResBufY, OMX_U8 *pResBufCb, OMX_U8 *pResBufCr);

/**
 * Function:  omxVCM4P2_IQIDCTMBReconYInter_DLx	
 *
 * Description:
 * Perform inverse discrete cosine transform,  inverse quantization and reconstruct the current luminance macroblock.
 *		(Category: Macroblock based function)
 * Return Value:  OMXResult
 * Notes:
 * This is a super-block function. This function can also be used in H.263 video coding.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the quantized data. This is a linear array containing all the 256 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  quant		Quantization parameter for AC coefficients  .
 * [in]  pRefBuf	Pointer to the best-matched macroblock in the reference (frame) buffer  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  pSrcMV	Pointer to the half-pixel motion vector for all the four blocks  .
 * [in]  width		Width of the Y component of the frame  
 * [out] pResBuf	Pointer to the location of the reference buffer where the luminance data is to be written  .
 *
 * Brief:	This is a middle level function call that performs inverse quantization for all the six blocks in the current macroblock.
 */

OMXResult omxVCM4P2_IQIDCTMBReconYInter_DLx (OMX_S16 *pSrcBuf, OMX_INT quant, OMX_U8 *pRefBuf, OMXVCMotionVector **pSrcMV, OMX_INT rndCtrl, OMX_INT width, OMX_U8 *pResBuf);

/**
 * Function:  omxVCM4P2_IQIDCTReconYInter_DLx	
 *
 * Description:
 * Perform inverse discrete cosine transform,  inverse quantization and reconstruct the current luminance macroblock.
 *		(Category: block based function)
 * Return Value:  OMXResult
 * Notes:
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the quantized data. This is a linear array containing all the 64 coefficients of the macroblock, whose coefficients are arranged in a serial fashion  .
 * [in]  quant		Quantization parameter for AC coefficients  .
 * [in]  pRefBuf	Pointer to the best-matched macroblock in the reference (frame) buffer  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  pSrcMV	Pointer to the half-pixel motion vector for the block  .
 * [in]  width		Width of the Y component of the frame  
 * [out] pResBuf	Pointer to the location of the reference buffer where the luminance data is to be written  .
 *
 * Brief:	This is a function call that performs inverse quantization for all the six blocks in the current macroblock.
 */

OMXResult omxVCM4P2_IQIDCTReconYInter_DLx (OMX_S16 *pSrcBuf, OMX_INT quant, OMX_U8 *pRefBuf, OMXVCMotionVector **pSrcMV, OMX_INT rndCtrl, OMX_INT width, OMX_U8 *pResBuf);


/**
 * Function:  omxVCM4P2_IQIDCTReconCInter_DLx		
 *
 * Description:
 * Perform inverse discrete cosine transform,  inverse quantization and reconstruct the current Chrominance block.
 *		(Category: Block based function)
 * Return Value:  OMXResult
 * Notes:
 * This is a super-block function. Reconstruction involves computing half-pixels for each of the blocks and adding them to the corresponding inverse quantized block data. In the input buffer (pSrcBuf), the coefficients of the block are assumed to be pre-processed (i.e.) assumed to have 64 coefficients arranged in the normal order with the invalid coefficients assigned to zero. This function can also be used in H.263 video coding.
 *
 * Parameters:	
 * [in]  pSrcBuf	Pointer to the quantized data. This is a linear array containing all the 64 coefficients of the current Cb/Cr block  .
 * [in]  quant		Quantization parameter for all the coefficients  .
 * [in]  pRefBuf	Pointer to the best-matched macroblock in the reference (frame) buffer  .
 * [in]  pSrcMV	Pointer to the half-pixel motion vector for all the four blocks  .
 * [in]  rndCtrl	Round control parameter used for half-pixel interpolation  .
 * [in]  width		Width of the chrominance  component of  the frame  
 * [out] pResBuf	Pointer to the location of the reference buffer where the luminance data is to be written  .
 *
 * Brief:	This is a middle level function call that performs inverse discrete cosine transform, inverse quantization and reconstruction of the current Cb/Cr block. 
 */

OMXResult omxVCM4P2_IQIDCTReconCInter_DLx (OMX_S16 *pSrcBuf, OMX_INT quant, OMX_U8 *pRefBuf, OMXVCMotionVector **pSrcMV, OMX_INT rndCtrl, OMX_INT width, OMX_U8 *pResBuf);

/** 
 *
 * Function:  omxVCM4P2_Sadmultiple_DLx	 
 *
 * Description:  
 * Computes absolute differences between target block and blocks in reference array
 *
 * Brief:	
 * Computes absolute differences between target block and blocks in reference array. The reference data and target data are assumed to be a luminance only block.
 *
 * Parameters:
 * [in]   pTargetBlk	- Pointer to target array (linear). 	8 byte aligned
 * [in]   pRefBlk		- Pointer to reference array.		1 byte aligned
 * [out]  pOutput	- Pointer to output array.
 * [in]   sParams		- Pointer to Parameters for Sadmultiple.
 *
 * OMXSadmultipleParam elements:
 * - Block_width	width of matching block	OMX_S16
 * - Block_height	height of matching block	OMX_S16
 * - Target_width	width of target array	OMX_S16
 * - ref_width	width of reference array	OMX_S16
 * - step_horz	Horizontal offset between matchings	OMX_S16
 * - step_vert	vertical offset between matchings.	OMX_S16
 * - nsteps_horz	number of steps horizontally	OMX_S16
 * - nsteps_vert	number of steps vertically	OMX_S16
 * - minmax_clear	
 *					0: retain previous min/max value
 *					1: clear previous min/max value	OMX_S16
 * - Minmax	
 *					0: Minimum SAD is calculated
 *					1: Maximum SAD is calculated	OMX_S16
 * - id_mode	This selects the type of id output	OMX_S16
 *				0: block_count
 *				1: address
 * - id_value	This selects whether id or min/max value is output	OMX_S16
 *				0: ID
 *				1: min/max value
 * - Thresh	Threshold. When SAD is strictly below 2*threshold, command
 *				stops running, outputs current min/max or corresponding
 *				id/address.	OMX_S16
 * - center_block	Indicates which block should have bias towards if there is a tie.	S16
 * - skip_field	The bit value indicates which block to skip.	OMX_S16
 *
 * Return Value: 
 * OMXResult
 *
 * 
 *
 */

OMXResult omxVCM4P2_Sadmultiple_DLx(OMX_U8 *pTargetBlk, OMX_U8 *pRefBlk, OMX_S16 *pOutput, OMXSadmultipleParam *sParams);


/**
 * Function: omxVCM4P2_DecodeMV_BVOP_Backward_DLx
 *
 * Description:
 * Pointwise vector substraction of 16-bit data type
 *
 * Remarks:
 * This function subtracts the elements of one vector from the corresponding
 * elements of a second vector. 
 * 
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within [0-7].
 * [in]  	pSrcDstMVB		pointer to the backward motion vector predictor
 * [in]  	fcodeBackward	a code equal to vop_fcode_backward in MPEG-4 bit
 *								stream syntax
 * [out] 	ppBitStream		*ppBitStream is updated after the block is decoded,
 *								so that it points to the current byte in the bit
 *								stream buffer
 * [out] 	pBitOffset		*pBitOffset is updated so that it points to the
 *								current bit position in the byte pointed by
 *								*ppBitStream
 * [out] 	pSrcDstMVB		pointer to the backward motion vector of the
 *								current macroblock. The backward motion vector
 *								predictor should be reset to zero at the
 *								beginning of each macroblock row.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeMV_BVOP_Backward_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     OMXVCMotionVector * pSrcDstMVB,
     OMX_INT fcodeBackward        
 );


/**
 * Function: omxVCM4P2_DecodeMV_BVOP_Forward_DLx
 *
 * Description:
 * Decodes motion vectors of the macroblock in B-VOP forward mode. After
 * decoding a macroblock of forward mode only the forward predictor is set
 * to the decoded forward vector.
 *
 * Remarks:
 * 
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7]
 * [in]  	pSrcDstMVF		pointer to the forward motion vector predictor
 * [in]  	fcodeForward	a code equal to vop_fcode_forward in MPEG-4 bit
 *								stream syntax
 * [out] 	ppBitStream		*ppBitStream is updated after the block is decoded,
 *								so that it points to the current byte in the bit
 *								stream buffer
 * [out] 	pBitOffset		*pBitOffset is updated so that it points to the
 *								current bit position in the byte pointed by
 *								*ppBitStream
 * [out] 	pSrcDstMVF		pointer to the forward motion vector of the current
 *								macroblock. The forward motion vector predictor
 *								should be reset to zero at the beginning of each
 *								macroblock row
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeMV_BVOP_Forward_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     OMXVCMotionVector * pSrcDstMVF,
     OMX_INT fcodeForward        
 );


/**
 * Function: omxVCM4P2_DecodeMV_BVOP_Interpolate_DLx
 *
 * Description:
 * Decodes motion vectors of the macroblock in B-VOP interpolate mode. After
 * decoding a macroblock of interpolate mode both the forward and backward
 * predictor are updated separately with the decoded vectors of the same type
 * (forward/backward).
 *
 * Remarks:
 * 
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7].
 * [in]  	pSrcDstMVF		pointer to the forward motion vector predictor.
 *								The forward motion vector predictor should be reset
 *								to zero at the beginning of each macroblock row.
 * [in]  	pSrcDstMVB		pointer to the backward motion vector predictor.
 *								The backward motion vector predictor should be
 *								reset to zero at the beginning of each macroblock row.
 * [in]  	fcodeForward	a code equal to vop_fcode_forward in MPEG-4 bit
 *								stream syntax
 * [in]  	fcodeBackward	a code equal to vop_fcode_backward in MPEG-4 bit
 *								stream syntax
 * [out] 	ppBitStream		*ppBitStream is updated after the block is decoded,
 *								so that it points to the current byte in the bit
 *								stream buffer
 * [out] 	pBitOffset		*pBitOffset is updated so that it points to the
 *								current bit position in the byte pointed by
 *								*ppBitStream
 * [out] 	pSrcDstMVF		pointer to the forward motion vector of the
 *								current macroblock
 * [out] 	pSrcDstMVB		pointer to the backward motion vector of the
 *								current macroblock
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeMV_BVOP_Interpolate_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     OMXVCMotionVector * pSrcDstMVF,
     OMXVCMotionVector * pSrcDstMVB,
     OMX_INT fcodeForward,
     OMX_INT fcodeBackward        
 );



/**
 * Function: omxVCM4P2_DecodeMV_BVOP_Direct_DLx
 *
 * Description:
 * Decodes motion vector(s) of the macroblock in B-VOP using direct mode.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream.  *pBitOffset is valid within
 *								[0-7].
 * [in]  	pSrcMV			pointer to the motion vector buffer of the
 *								co-located macroblock in the most recently
 *								decoded I- or P-VOP
 * [in]  	pTranspSrcMB	pointer to the transparent status buffer of the
 *								co-located macroblock
 * [in]  	TRB				the difference in temporal reference of the B-VOP
 *								and the previous reference VOP
 * [in]  	TRD				the difference in temporal reference of the
 *								temporally next reference VOP with temporally
 *								previous reference VOP
 * [out] 	ppBitStream		*ppBitStream is updated after the block is
 *								decoded, so that it points to the current byte
 *								in the bit stream buffer
 * [out] 	pBitOffset		*pBitOffset is updated so that it points to
 *								the current bit position in the byte pointed
 *								by *ppBitStream
 * [out] 	pDstMVF			pointer to the forward motion vector buffer of
 *								the current macroblock which contains decoded
 *								forward motion vector
 * [out] 	pDstMVB			pointer to the backward motion vector buffer of
 *								the current macroblock which contains decoded
 *								backward motion vector
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeMV_BVOP_Direct_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     const OMXVCMotionVector * pSrcMV,
     OMXVCMotionVector * pDstMVF,
     OMXVCMotionVector * pDstMVB,
     OMX_U8 * pTranspSrcMB,
     OMX_INT TRB,
     OMX_INT TRD        
 );



/**
 * Function: omxVCM4P2_DecodeMV_BVOP_DirectSkip_DLx
 *
 * Description:
 * Decodes motion vector(s) of the macroblock in B-VOP using direct mode when
 * the current macroblock is skipped. A macroblock in B-VOP is skipped if modb
 * == 1.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcMV			pointer to the motion vector buffer of the
 *								co-located macroblock in the most recently decoded
 *								I- or P-VOP
 * [in]  	pTranspSrcMB	pointer to the transparent status buffer of the
 *								co-located macroblock
 * [in]  	TRB				the difference in temporal reference of the B-VOP
 *								and the previous reference VOP
 * [in]  	TRD				the difference in temporal reference of the
 *								temporally next reference VOP with temporally
 *								previous reference VOP
 * [out] 	pDstMVF			pointer to the forward motion vector buffer of
 *								the current macroblock which contains decoded
 *								forward motion vector
 * [out] 	pDstMVB			pointer to the backward motion vector buffer of
 *								the current macroblock which contains decoded
 *								backward motion vector
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */
OMXResult omxVCM4P2_DecodeMV_BVOP_DirectSkip_DLx(
     const OMXVCMotionVector * pSrcMV,
     OMXVCMotionVector * pDstMVF,
     OMXVCMotionVector * pDstMVB,
     OMX_U8 * pTranspSrcMB,
     OMX_INT TRB,
     OMX_INT TRD        
 );


/**
 * Function: omxVCM4P2_DecodeCAEIntraH_U8_DLx;omxVCM4P2_DecodeCAEIntraV_U8_DLx
 *
 * Description:
 * Performs Context Arithmetic Code decoding in intra macroblock. H indicates
 * scan type is horizontal. V indicates scan type is vertical. Convert ratio
 * is supported in these functions.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte
 *								from which the intra block starts
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7]
 * [in]  	pBinarySrcDst	pointer to the Source-Dest Binary macroblock the
 *								left and top border should be loaded before
 * [in]  	step			width of source-dest binary plane, in bytes
 * [in]  	blocksize		macroblock size, if convert ratio take effects,
 *								it means subsampled macro block size
 * [out] 	ppBitStream		pointer to the pointer to the current byte from
 *								which the intra block starts
 * [out] 	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7]
 * [out] 	pBinarySrcDst	pointer to the Source-Dest Binary macroblock the
 *								left and top border should be loaded before
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeCAEIntraH_U8_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT *pBitOffset,
     OMX_U8 * pBinarySrcDst,
     OMX_INT step,
     OMX_INT blocksize        
 );



OMXResult omxVCM4P2_DecodeCAEIntraV_U8_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT *pBitOffset,
     OMX_U8 * pBinarySrcDst,
     OMX_INT step,
     OMX_INT blocksize        
 );



/**
 * Function: omxVCM4P2_DecodeCAEInterH_U8_DLx;omxVCM4P2_DecodeCAEInterV_U8_DLx
 *
 * Description:
 * Performs Context Arithmetic Code decoding in inter macroblock. H indicates
 * scan type is horizontal. V indicates scan type is vertical. Convert ratio
 * is supported in these functions.
 *
 * Remarks:
 * This function multiplies the elements of one vector to the corresponding elements 
 * of a second vector. 
 * 
 *
 * Parameters:
 * [in]  	ppBitStream		pointer to the pointer to the current byte from
 *								which the intra block starts
 * [in]  	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7]
 * [in]  	pBinarySrcPred	pointer to the related macroblock in the reference
 *								binary plane, the left and top border should be
 *								loaded before. But pointer points to top-left corner
 *								of this macro block, not the extended zone.
 * [in]  	pBinarySrcDst	pointer to the Source-Dest Binary macroblock the
 *								left and top border should be loaded before
 * [in]  	offsetPred		the bit position of first pixel in reference
 *								macroblock, valid within Bits 0 to 7 Where:
 *								  -MSB=zero(0)
 *								  -LSB=seven(7)
 * [in]  	step			width of source-dest binary plane and reference
 *								plane, in byte. If blocksize not equals to 16,
 *								it indicates binary buffer step.
 * [in]  	blocksize		macroblock size, if convert ratio take effects,
 *								it means subsampled macro block size
 * [out] 	ppBitStream		pointer to the pointer to the current byte from
 *								which the intra block starts
 * [out] 	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7]
 * [out] 	pBinarySrcDst	pointer to the Source-Dest Binary macroblock the
 *								left and top border should be loaded before
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_DecodeCAEInterH_U8_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     const OMX_U8 * pBinarySrcPred,
     OMX_INT offsetPred,
     OMX_U8 * pBinarySrcDst,
     OMX_INT step,
     OMX_INT blocksize        
 );


OMXResult omxVCM4P2_DecodeCAEInterV_U8_DLx (
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     const OMX_U8 * pBinarySrcPred,
     OMX_INT offsetPred,
     OMX_U8 * pBinarySrcDst,
     OMX_INT step,
     OMX_INT blocksize        
 );

/**
 * Function: omxVCM4P2_DecodeMVS_DLx
 *
 * Description:
 * Decode MVs (Motion Vector of shape) according to the spec.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	ppBitStream		Pointer to the pointer to the current byte in
 *								the bit stream buffer.
 * [in]  	pBitOffset		Pointer to the bit position in the byte pointed
 *								by *ppBitStream. Valid within 0 to 7.
 * [in]  	pSrcDstMVS		Pointer to the shape motion vector buffer of the
 *								current BAB.
 * [in]  	pSrcBABMode		Pointer to the BAB mode buffer of current BAB,
 *								which stored in the BAB mode plane.
 * [in]  	stepBABMode		The width of the BAB mode plane.
 * [in]  	pSrcMVLeftMB    Pointers to the motion vector buffers of the
 *								macroblocks spacially at the left, upper and
 *								upper-right side of the current macroblock
 *								respectively.
 * [in]   pSrcMVUpperMB   Pointers to the motion vector buffers of the
 *								macroblocks spacially at the left, upper and
 *								upper-right side of the current macroblock
 *								respectively.
 * [in]   pSrcMVUpperRightMB    Pointers to the motion vector buffers of the
 *								macroblocks spacially at the left, upper and
 *								upper-right side of the current macroblock
 *								respectively.
 * [in]  	pTranspLeftMB    Pointers to the transparent status buffers of
 *								the macroblocks, spacially at the left, upper,
 *								and upper-right side of, and the current
 *								macroblock respectively.
 * [in]   pTranspUpperMB   Pointers to the transparent status buffers of
 *								the macroblocks, spacially at the left, upper,
 *								and upper-right side of, and the current
 *								macroblock respectively.
 * [in]   pTranspUpperRightMB  Pointers to the transparent status buffers of
 *								the macroblocks, spacially at the left, upper,
 *								and upper-right side of, and the current
 *								macroblock respectively.
 * [in]  	predFlag		The flag will be set zero, while the current VOP
 *								is BVOP or the current VOL is shape only mode;
 *								else, the flag is nonzero.
 * [out] 	pSrcDstMVS		Pointer to the decoded motion vector of shape.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */
OMXResult omxVCM4P2_DecodeMVS_DLx(
     const OMX_U8 **ppBitStream,
     OMX_INT *pBitOffset,
     OMXVCMotionVector * pSrcDstMVS,
     const OMX_U8 * pSrcBABMode,
     OMX_INT stepBABMode,
     const OMXVCMotionVector * pSrcMVLeftMB,
     const OMXVCMotionVector * pSrcMVUpperMB,
     const OMXVCMotionVector * pSrcMVUpperRightMB,
     const OMX_U8 * pTranspLeftMB,
     const OMX_U8 * pTranspUpperMB,
     const OMX_U8 * pTranspUpperRightMB,
     OMX_INT predFlag        
 );
 
 /**
 * Function: omxVCM4P2_BlockMatchSOS_Integer_16x16_DLx,
 *
 * Description:
 * Performs a 16x16 block search; estimates motion vector and associated minimum sum of squared error (SOS).  
 * Both the input and output motion vectors are represented using half-pixel units, and 
 * therefore a shift left or right by 1 bit may be required, respectively, to match the 
 * input or output MVs with other functions that either generate output MVs or expect 
 * input MVs represented using integer pixel units. 
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcRefBuf		pointer to the reference Y plane; points to the reference MB that 
 *                    corresponds to the location of the current macroblock in the current 
 *                    plane.
 * [in]  	refWidth		  width of the reference plane
 * [in]  	pRefRect		  pointer to the valid rectangular in reference plane. Relative to image origin. 
 *                    It's not limited to the image boundary, but depended on the padding. For example, 
 *                    if you pad 4 pixels outside the image border, then the value for left border 
 *                    can be -4
 * [in]  	pSrcCurrBuf		pointer to the current macroblock extracted from original plane (linear array, 
 *                    256 entries); must be aligned on an 8-byte boundary.
 * [in]   pCurrPointPos	position of the current macroblock in the current plane
 * [in]   pSrcPreMV		  pointer to predicted motion vector; NULL indicates no predicted MV
 * [in]   pSrcPreSOS		pointer to SOS associated with the predicted MV (referenced by pSrcPreMV)
 * [in]   searchRange		search range for 16X16 integer block,the units of it is full pixel,the search range 
 *                    is the same in all directions.It is in inclusive of the boundary and specified in 
 *                    terms of integer pixel units.
 * [in]   pMESpec			  vendor-specific motion estimation specification structure; must have been allocated 
 *                    and then initialized using omxVCM4P2_MEInit prior to calling the block matching 
 *                    function.
 * [out] 	pDstMV			pointer to estimated MV
 * [out] 	pDstSOS			pointer to minimum SOS
 *
 * Return Value:
 * OMX_StsNOErr - no error.
 * OMX_StsBadArgErr - bad arguments
 *
 */

OMXResult omxVCM4P2_BlockMatchSOS_Integer_16x16_DLx(
     OMX_U8 *pSrcRefBuf,
     OMX_INT refWidth,
     OMXRect *pRefRect,
     OMX_U8 *pSrcCurrBuf,
     OMXVCM4P2Coordinate *pCurrPointPos,
     OMXVCMotionVector *pSrcPreMV,
     OMX_INT *pSrcPreSOS,
     OMX_INT searchRange,
     void *pMESpec,
     OMXVCMotionVector *pDstMV,
     OMX_INT *pDstSOS        
 );

/**
 * Function: omxVCM4P2_BlockMatchSOS_Integer_8x8_DLx
 *
 * Description:
 * Performs an 8x8 block search; estimates motion vector and associated minimum SOS.  Both 
 * the input and output motion vectors are represented using half-pixel units, and therefore 
 * a shift left or right by 1 bit may be required, respectively, to match the input or output 
 * MVs with other functions that either generate output MVs or expect input MVs represented 
 * using integer pixel units.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcRefBuf		pointer to the reference Y plane; points to the reference MB that 
 *                    corresponds to the location of the current macroblock in the current 
 *                    plane.
 * [in]  	refWidth		  width of the reference plane
 * [in]  	pRefRect		  pointer to the valid reference plane rectangle; coordinates are specified 
 *                    relative to the image origin.  Rectangle boundaries may extend beyond 
 *                    image boundaries if the image has been padded.
 * [in]  	pSrcCurrBuf		pointer to the current macroblock extracted from original plane (linear 
 *                    array, 256 entries); must be aligned on an 8-byte boundary.  The step 
 *                    between lines of the 8x8 block is 16 bytes.
 * [in]  	pCurrPointPos	position of the current macroblock in the current plane
 * [in]  	pSrcPreMV		  pointer to predicted motion vector; NULL indicates no predicted MV
 * [in]  	pSrcPreSOS		pointer to SOS associated with the predicted MV (referenced by pSrcPreMV)
 * [in]  	searchRange		search range for 8x8 integer block,the units of it is full pixel,the 
 *                    search range is the same in all directions.It is in inclusive of the 
 *                    boundary and specified in terms of integer pixel units.
 * [in]  	pMESpec 	    implementation-specific state,can be set to NULL when using full search
 * [out] 	pDstMV			pointer to estimated MV
 * [out] 	pDstSOS			pointer to minimum SOS
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_BlockMatchSOS_Integer_8x8_DLx(
     OMX_U8 *pSrcRefBuf,
     OMX_INT refWidth,
     OMXRect *pRefRect,
     OMX_U8 *pSrcCurrBuf,
     OMXVCM4P2Coordinate *pCurrPointPos,
     OMXVCMotionVector *pSrcPreMV,
     OMX_INT *pSrcPreSOS,
     OMX_INT searchRange,
     void *pMESpec,
     OMXVCMotionVector *pDstMV,
     OMX_INT *pDstSOS        
 );



/**
 * Function: omxVCM4P2_BlockMatchSOS_Half_16x16_DLx
 *
 * Description:
 * Performs a 16x16 block match with half-pixel resolution.  Returns the estimated 
 * motion vector and associated minimum SOS.  This function estimates the half-pixel 
 * motion vector by interpolating the integer resolution motion vector referenced 
 * by the input parameter pSrcDstMV, i.e., the initial integer MV is generated 
 * externally.  The input parameters pSrcRefBuf and pSearchPointRefPos should be 
 * shifted by the winning MV of 16x16 integer search prior to calling BlockMatch_Half_16x16.  
 * The function BlockMatch_Integer_16x16 may be used for integer motion estimation.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcRefBuf		pointer to the reference Y plane; points to the reference MB 
 *                    that corresponds to the location of the current macroblock in 
 *                    the	current plane.
 * [in]  	refWidth		  width of the reference plane
 * [in]  	pRefRect		  reference plane valid region rectangle
 * [in]  	pSrcCurrBuf		pointer to the current macroblock extracted from original plane 
 *                    (linear array, 256 entries); must be aligned on an 8-byte boundary. 
 * [in]  	pSearchPointRefPos	position of the starting point for half pixel search (specified 
 *                          in terms of integer pixel units) in the reference plane.
 * [in]  	rndVal			  rounding control bit for half pixel motion estimation; 
 *                    0=rounding control disabled; 1=rounding control enabled
 * [in]  	pSrcDstMV		pointer to the initial MV estimate; typically generated during a prior 
 *                  16X16 integer search and its unit is half pixel.
 * [out] pSrcDstMV		pointer to estimated MV
 * [out] pDstSOS			pointer to minimum SOS
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_BlockMatchSOS_Half_16x16_DLx(
     OMX_U8 *pSrcRefBuf,
     OMX_INT refWidth,
     OMXRect *pRefRect,
     OMX_U8 *pSrcCurrBuf,
     OMXVCM4P2Coordinate *pSearchPointRefPos,
     OMX_INT rndVal,
     OMXVCMotionVector *pSrcDstMV,
     OMX_INT *pDstSOS        
 );



/**
 * Function: omxVCM4P2_BlockMatchSOS_Half_8x8_DLx
 *
 * Description:
 * Performs an 8x8 block match with half-pixel resolution.  Returns the estimated motion 
 * vector and associated minimum SOS.  This function estimates the half-pixel motion 
 * vector by interpolating the integer resolution motion vector referenced by the input 
 * parameter pSrcDstMV, i.e., the initial integer MV is generated externally.  The input 
 * parameters pSrcRefBuf and pSearchPointRefPos should be shifted by the winning MV of 
 * 8x8 integer search prior to calling BlockMatch_Half_8x8. The function BlockMatch_Integer_8x8 
 * may be used for integer motion estimation.  
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcRefBuf		pointer to the reference Y plane; points to the reference MB that 
 *                    corresponds to the location	of the current macroblock in the current 
 *                    plane.
 * [in]  	refWidth		  width of the reference plane
 * [in]  	pRefRect		  reference plane valid region rectangle
 * [in]  	pSrcCurrBuf		pointer to the current macroblock extracted from original plane (linear 
 *                    array, 256 entries); must be aligned on an 8-byte boundary.  The step 
 *                    between lines of the 8x8 block is 16 bytes.
 * [in]  	pSearchPointRefPos	position of the starting point for half pixel search (specified 
 *                          in terms of integer pixel units) in the reference plane.
 * [in]  	rndVal			  rounding control bit for half pixel motion estimation; 
 *                    0=rounding control disabled; 1=rounding control enabled
 * [in]  	pSrcDstMV		pointer to the initial MV estimate; typically generated during a prior 
 *                  8X8 integer search and its unit is half pixel.
 * [out] 	pSrcDstMV			pointer to estimated MV
 * [out] 	pDstSOS			pointer to minimum SOS
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_BlockMatchSOS_Half_8x8_DLx(
     OMX_U8 *pSrcRefBuf,
     OMX_INT refWidth,
     OMXRect *pRefRect,
     OMX_U8 *pSrcCurrBuf,
     OMXVCM4P2Coordinate *pSearchPointRefPos,
     OMX_INT rndVal,
     OMXVCMotionVector *pSrcDstMV,
     OMX_INT *pDstSOS        
 );
 
 
 /**
 * Function: omxVCM4P2_PadCurrent_16x16_U8_I_DLx;omxVCM4P2_PadCurrent_8x8_U8_I_DLx
 *
 * Description:
 * Performs horizontal and vertical repetitive padding process on luminance/alpha
 * macroblock or chrominance block. The horizontal and vertical repetitive
 * padding processes are specified in subclause 7.6.1.1 and 7.6.1.2 of ISO/IEC
 * 14496-2 respectively.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcDst			pointer to the block to be padded
 * [in]  	stepTexture		width of the source texture (Luminance,
 *								Chrominance or Grayscale alpha) plane (numbered
 *								with pixel)
 * [in]  	stepBinary		width of the source binary alpha plane (for
 *								16X16 version) or source binary alpha buffer
 *								(for 8X8 version) (numbered with byte)
 * [in]  	pSrcBAB			pointer to the binary alpha plane (for 16X16
 *								version) or binary alpha block buffer (for 8X8
 *								version). In 8X8 version, the buffer contains
 *								32 bytes (256 bits) for 16 by 16 luminance or
 *								alpha block, or 8 bytes (64 bits) for 8 by 8
 *								chrominance block.
 * [out] 	pSrcDst			pointer to the padded block
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_PadCurrent_16x16_U8_I_DLx(
     const OMX_U8 * pSrcBAB,
     OMX_INT stepBinary,
     OMX_U8 * pSrcDst,
     OMX_INT stepTexture        
 );



OMXResult omxVCM4P2_PadCurrent_8x8_U8_I_DLx(
     const OMX_U8 * pSrcBAB,
     OMX_INT stepTexture,
     OMX_U8 * pSrcDst        
 );



/**
 * Function: omxVCM4P2_PadMBHorizontal_U8_DLx
 *
 * Description:
 * Performs horizontal extended padding process on exterior macroblock, which
 * includes luminance, chrominance and alpha (if available) blocks, immediately
 * next to boundary macroblock.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	stepYA		width of the luminance or alpha planes. (numbered
 *							with pixel)
 * [in]  	stepCbCr	width of the Chrominance planes. (numbered with pixel)
 * [in]  	pSrcY		pointer to one of the vertical border of the
 *							boundary luminance blocks that are chosen to pad the
 *							exterior macroblock
 * [in]  	pSrcCb		pointer to one of the vertical border of the
 *							boundary Cb block that is chosen to pad the exterior
 *							macroblock 
 * [in]  	pSrcCr		pointer to one of the vertical border of the boundary
 *							Cr block that is chosen to pad the exterior macroblock
 * [in]  	pSrcA		pointer to one of the horizontal border of the
 *							boundary alpha blocks that are chosen to pad the
 *							exterior macroblock. If pSrcA equals to NULL, then no
 *							alpha plane is available. Otherwise, the alpha plane
 *							should be padded.
 * [out] 	pDstY		pointer to the padded exterior luminance blocks
 * [out] 	pDstCb		pointer to the padded exterior Cb block
 * [out] 	pDstCr		pointer to the padded exterior Cr block
 * [out] 	pDstA		pointer to the padded exterior alpha blocks
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_PadMBHorizontal_U8_DLx(
     const OMX_U8 * pSrcY,
     const OMX_U8 * pSrcCb,
     const OMX_U8 * pSrcCr,
     const OMX_U8 * pSrcA,
     OMX_U8 * pDstY,
     OMX_U8 * pDstCb,
     OMX_U8 * pDstCr,
     OMX_U8 * pDstA,
     OMX_INT stepYA,
     OMX_INT stepCbCr        
 );




/**
 * Function: omxVCM4P2_PadMBVertical_U8_DLx
 *
 * Description:
 * Performs vertical extended padding process on exterior macroblock, which
 * includes luminance, chrominance and alpha (if available) blocks, immediately
 * next to boundary macroblock.
 *
 * Remarks:
 * 
 *
 * Parameters:
 * [in]  	stepYA		width of the Luminance and/or alpha planes
 * [in]  	stepCbCr	width of the Chrominance planes
 * [in]  	pSrcY		pointer to one of the horizontal border of
 *							the boundary luminance blocks that are chosen to
 *							pad the exterior macroblock
 * [in]  	pSrcCb		pointer to one of the horizontal border of the
 *							boundary Cb block that is chosen to pad the exterior
 *							macroblock
 * [in]  	pSrcCr		pointer to one of the horizontal border of the
 *							boundary Cr block that is chosen to pad the exterior
 *							macroblock
 * [in]  	pSrcA		pointer to one of the horizontal border of the 
 *							boundary alpha blocks that are chosen to pad the
 *							exterior macroblock. If pSrcA equals to NULL, then
 *							no alpha plane is available. Otherwise, the alpha
 *							plane should be padded in MB version.
 * [out] 	pDstY		pointer to the padded exterior luminance blocks
 * [out] 	pDstCb		pointer to the padded exterior Cb block
 * [out] 	pDstCr		pointer to the padded exterior Cr block
 * [out] 	pDstA		pointer to the padded exterior alpha blocks
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_PadMBVertical_U8_DLx(
     const OMX_U8 * pSrcY,
     const OMX_U8 * pSrcCb,
     const OMX_U8 * pSrcCr,
     const OMX_U8 * pSrcA,
     OMX_U8 * pDstY,
     OMX_U8 * pDstCb,
     OMX_U8 * pDstCr,
     OMX_U8 * pDstA,
     OMX_INT stepYA,
     OMX_INT stepCbCr        
 );



/**
 * Function: omxVCM4P2_PadMBGray_U8_DLx
 *
 * Description:
 * Fills gray value in exterior macroblock (includes luminance, chrominance
 * and alpha (if available) blocks) that is not located next to any boundary
 * macroblock.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	grayVal		the gray value to fill the exterior macroblock/block.
 *							It should be set to 2bits_per_pixel ?1, where
 *							bits_per_pixel = 8 here.
 * [in]  	stepYA		width of the Luminance and/or alpha planes. (numbered
 *							with pixel)
 * [in]  	stepCbCr	width of the Chrominance planes.
 * [out] 	pDstY		pointer to the padded exterior luminance blocks.
 *							pDstY should be 32-bit aligned.
 * [out] 	pDstCb		pointer to the padded exterior Kb block. DstCb
 *							should be 32-bit aligned.
 * [out] 	pDstCr		pointer to the padded exterior Cr block. pDstCr
 *							should be 32-bit aligned.
 * [out] 	pDstA		pointer to the padded exterior alpha blocks. If pDstA
 *							equals to NULL, then no alpha plane is available.
 *							Otherwise, the alpha plane should be padded in MB
 *							version. pDstA should be 32-bit aligned.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_PadMBGray_U8_DLx(
     OMX_U8 grayVal,
     OMX_U8 * pDstY,
     OMX_U8 * pDstCb,
     OMX_U8 * pDstCr,
     OMX_U8 * pDstA,
     OMX_INT stepYA,
     OMX_INT stepCbCr        
 );
 
 /**
 * Function: omxVCM4P2_PadMV_DLx
 *
 * Description:
 * Performs motion vector padding for a macroblock.
 *
 * Remarks:
 *
 * Parameters:
 * [in]  	pSrcDstMV		pointer to motion vector buffer of the current
 *								macroblock
 * [in]  	pTransp			pointer to transparent status buffer of the
 *								current macroblock
 * [out] 	pSrcDstMV		pointer to motion vector buffer in which the
 *								motion vectors have been padded
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_PadMV_DLx(
     OMXVCMotionVector * pSrcDstMV,
     OMX_U8 * pTransp        
 );


/**
 * Function: omxVCM4P2_DecodePadMV_PVOP_WithTransparent_DLx
 *
 * Description:
 * Decodes and pads four motion vectors of the non-intra macroblock in P-VOP.
 * The motion vector padding process is specified in subclause 7.6.1.6 of
 * ISO/IEC 14496-2.
 *
 * Remarks:
 * 
 *
 * Parameters:
 * [in]	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]	pBitOffset		pointer to the bit position in the byte pointed
 *								to by *ppBitStream. *pBitOffset is valid within
 *								[0-7].
 * [in]	pSrcMVLeftMB    pointers to the motion vector buffers of the
 *								macroblocks specially at the left side of the current macroblock
 *								respectively.
 * [in]	pSrcMVUpperMB   pointers to the motion vector buffers of the
 *								macroblocks specially at the upper side of the current macroblock
 *								respectively.
 * [in]	pSrcMVUpperRightMB	pointers to the motion vector buffers of the
 *								macroblocks specially at the upper-right side of the current macroblock
 *								respectively.
 * [in]	pTranspLeftMB     
 * [in]	pTranspUpperMB
 * [in]	pTranspUpperRightMB
 * [in]	pTranspCurMB	pointers to the transparent status buffers of
 *								the macroblocks specially at the left, upper
 *								and upper-right side of, and the current
 *								macroblock respectively. Set to
 *								OMX_VC_TRANSPARENT if outside boundary
 * [in]	fcodeForward	a code equal to vop_fcode_forward in MPEG-4
 *								bit stream syntax
 * [in]	MBType			the type of the current macroblock. If MBType
 *								is not equal to OMX_VC_INTER4V, the destination
 *								motion vector buffer is still filled with the
 *								same decoded vector.
 * [out]	ppBitStream		*ppBitStream is updated after the block is decoded,
 *								so that it points to the current byte in the bit
 *								stream buffer
 * [out]	pBitOffset		*pBitOffset is updated so that it points to the
 *								current bit position in the byte pointed by
 *								*ppBitStream
 * [out]	pDstMVCurMB		pointer to the motion vector buffer of the current
 *								macroblock which contains four decoded motion vectors
 *
 * Return Value:
 * OMX_StsNoErr - no error
 * OMX_StsBadArgErr - bad arguments
 *      -	At least one of the following pointers is NULL: ppBitStream, *ppBitStream,   
 *                           pBitOffset, pTranspLeftMB, pTranspUpperMB, pTranspUpperRight, 
 *                           pTranspCurMB, pDstMVCurMB 
 *          or
 *      -	At least one of following cases is true: *pBitOffset exceeds [0,7], fcodeForward 
 *          exceeds (0,7], MBType less than zero, transparent status or the motion vector buffer 
 *          is not 32-bit aligned.
 * OMX_StsErr - status error
 *
 */

OMXResult omxVCM4P2_DecodePadMV_PVOP_WithTransparent_DLx(
     const OMX_U8 ** ppBitStream,
     OMX_INT * pBitOffset,
     OMXVCMotionVector * pSrcMVLeftMB,
     OMXVCMotionVector *pSrcMVUpperMB,
     OMXVCMotionVector * pSrcMVUpperRightMB,
     OMXVCMotionVector * pDstMVCurMB,
     OMX_U8 * pTranspLeftMB,
     OMX_U8 * pTranspUpperMB,
     OMX_U8 * pTranspUpperRightMB,
     OMX_U8 * pTranspCurMB,
     OMX_INT fcodeForward,
     OMXVCM4P2MacroblockType MBType        
 );

/**
 * Function: omxVCM4P2_EncodeMV_WithTransparent_DLx
 *
 * Description:
 * Predicts a motion vector for the current macroblock, encodes the difference, and writes 
 * the output to the stream buffer.  The input MVs pMVCurMB, pSrcMVLeftMB, pSrcMVUpperMB, 
 * and pSrcMVUpperRightMB should lie within the ranges associated with the input parameter 
 * fcodeForward, as described in ISO/IEC 14496-2, subclause 7.6.3.  This function provides 
 * a superset of the functionality associated with the function omxVCM4P2_FindMVpred.
 *
 * Remarks:
 * 
 *
 * Parameters:
 * [in]	ppBitStream		pointer to the pointer to the current byte in
 *								the bit stream buffer
 * [in]	pBitOffset		pointer to the bit position in the byte pointed
 *								by *ppBitStream. Valid within 0 to 7.
 * [in]	pMVCurMB		pointer to the current macroblock motion vector
 * [in]	pSrcMVLeftMB	pointer to the source left macroblock motion vector
 * [in]	pSrcMVUpperMB	pointer to source upper macroblock motion vector
 * [in]	pSrcMVUpperRightMB	pointer to source upper right MB motion vector
 * [in] 	pTranspCurMB	pointer to the transparent status buffers of the
 *								current macroblock
 * [in]	pTranspLeftMB	pointer to the transparent status buffers of the
 *								source left macroblock
 * [in]	pTranspUpperMB	pointer to the transparent status buffers of the
 *								source upper macroblock
 * [in]	pTranspUpperRightMB	pointer to the transparent status buffers of
 *									the source upper macroblock
 * [in]	fcodeForward	an integer with values from 1 to 7. This is used
 *								in encoding motion vectors related to search range.
 * [in]	MBType			macro block type, taking values from 0 to 9
 * [out]	ppBitStream		pointer to the pointer to the current byte in the
 *								bit stream buffer
 * [out]	pBitOffset		pointer to the bit position in the byte pointed
 *								by *ppBitStream
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxVCM4P2_EncodeMV_WithTransparent_DLx(
     OMX_U8 **ppBitStream,
     OMX_INT *pBitOffset,
     OMXVCMotionVector * pMVCurMB,
     OMXVCMotionVector * pSrcMVLeftMB,
     OMXVCMotionVector * pSrcMVUpperMB,
     OMXVCMotionVector * pSrcMVUpperRightMB,
     OMX_U8 * pTranspCurMB,
     OMX_U8 * pTranspLeftMB,
     OMX_U8 * pTranspUpperMB,
     OMX_U8* pTranspUpperRightMB,
     OMX_INT fcodeForward,
     OMXVCM4P2MacroblockType MBType        
 );

/**
 * EndDomain: M4P2
 */

/******************************************************************************************/
/**
 *
 *  NewDomain: M4P10 The MPEG4 Part10 Codec subdomain
 *  WithinDomain: VC
 *
 *  StartDomain: M4P10
 */
/**
 * Function: OMXVCM4P10_DeblockingFilterMB_DLx
 *
 * Description:
 * Applies deblocking filter to a complete macroblock, including both luminance and chrominance components.
 *
 * [in] ppSrcDst - pointers to the unfiltered Y, U, and V buffers for the current macroblock.
 *                    -- ppSrcDst[0] - pointer to the Y component, must be 16-byte aligned.
 *                    -- ppSrcDst[1] - pointer to the U component, must be 8-byte aligned.
 *                   -- ppSrcDst[2] - pointer to the V component, must be 8-byte aligned.
 * [in] pStep - 3-element array of steps for the Y, U, and V planes.
 *                   -- pStep[0] - Y plane step, must be a multiple of 16
 *                   -- pStep[1] - U plane step, must be a multiple of 8
 *                   -- pStep[2] - V plane step, must be a multiple of 8
 * [in] pCurrMB - pointer to the OMXVCM4P10MBInfo structure for the current macroblock
 * [in] pLeftMB - pointer to the OMXVCM4P10MBInfo structure for the left neighboring macroblock; must
 *                  be set equal to NULL if the left neighboring block is unavailable.
 * [in] pAboveMB - pointer to the OMXVCM4P10MBInfo structure for the above neighboring macroblock;
 *                  must be set equal to NULL if the above neighboring block is unavailable.
 * [in] pCbp4x4 - pointer to an array containing 4x4 CBP for current current, top, and left MBs.
 *                   -- pCbp4x4[0] - current
 *                   -- pCbp4x4[1] - top
 *                   -- pCbp4x4[2] - left
 * [in] AlphaOffset - specifies the offset used in accessing the alpha deblocking filter table; refer to subclause 7.4.3 of ISO/IEC 14496-10
 * [in] BetaOffset - specifies the offset used in accessing the beta deblocking filter table; refer to subclause 7.4.3 of ISO/IEC 14496-10
 * [in] pBS - pointer to a 16x2 table of BS parameters arranged in scan block order for vertical edges and
 *              then horizontal edges; valid in the range [0,4] with the following restrictions: i) pBS[i]== 4 may
 *              occur only for 0<=i<=3, ii) pBS[i]== 4 if and only if pBS[i^1]== 4. Must be 4-byte aligned
 * [out] ppSrcDst - pointers to the filtered Y, U, and V buffers for the current macroblock
 *                   -- ppSrcDst[0] - pointer to the Y component, must be 16-byte aligned.
 *                   -- ppSrcDst[1] - pointer to the U component, must be 8-byte aligned.
 *                   -- ppSrcDst[2] - pointer to the V component, must be 8-byte aligned.
 * Return value
 *	Standard OMXResult result.  See enumeration for possible result codes
 */ 
OMXResult OMXVCM4P10_DeblockingFilterMB_DLx (
			OMX_U8 **ppSrcDst, 
			const OMX_INT *pStep,
			const OMXVCM4P10MBInfo *pCurrMB,
			const OMXVCM4P10MBInfo *pLeftMB,
			const OMXVCM4P10MBInfo *pAboveMB,
			const OMX_U16 *pCbp4x4, 
			OMX_S8 AlphaOffset,
			OMX_S8 BetaOffset,
			const OMX_U8 *pBS);
/**
 * Function: DequantTransformResidualFromPair_C1_DLx
 *
 * Description:
 * Reconstruct the 4x4 residual block from coefficient-position pair buffer, perform dequantisation and integer inverse transformation for 4x4 block of residuals and update the pair buffer pointer to next non-empty block.  
 * [in] ppSrc  double pointer to residual coefficient-position pair buffer output by CALVC decoding
 * [in] pDC    pointer to the DC coefficient of this block; NULL if it doesn't exist
 * [in] QP     quantization parameter
 * [in] AC     flag indicating if at least one non-zero coefficient exists
 * [out] pDst  pointer to the reconstructed 4x4 block
 *Return value
 *	Standard OMXResult result.  See enumeration for possible result codes
 */ 

OMXResult omxVCM4P10_DequantTransformResidualFromPair_C1_DLx(
	           OMX_U8 **ppSrc, 
			   OMX_S16 *pDst,
			   OMX_INT QP,
			   OMX_S16* pDC,
			   int AC ); 

/**
 * EndDomain: M4P10
 */

/* **************************************************************************************** */
/**
 *
 *  NewDomain: JP The JPEG Image Codec Subdomain
 *  WithinDomain: IC
 *
 *  StartDomain: JP
 */
/* **************************************************************************************** */


/**
 * Function: omxICJP_DCTQuantFwd_Multiple_S16_I_DLx
 *
 * Brief:
 * Multiple 8x8 block FDCT with quantization function.
 *
 * Description:
 * This function implements forward DCT with quantization for the 8-bit image data. It processes
 * multiple adjacent blocks (8x8).The blocks are assumed to be part of a planarized buffer.
 * This function needs to be called separately for luma and chroma buffers with the respective quantization table.
 * Output matrix is the transpose of the explicit result.
 * As a result, the Huffman coding functions in this library handle transpose as well.
 *
 *
 * Parameters:
 * [in]  pSrcDst    Identifies coefficient block(8x8) buffer for in-place processing. This start address
 *                      must be 8-byte aligned. The input components are bounded on the interval [-128, 127] within
 *                      a signed 16-bit container.
 * [in]    nBlocks        the number of 8x8 blocks to be processed.
 * [in]    pQuantFwdTable identifies the quantization table which was generated from
 *                            "DCTQuantFwdTableInit_JPEG_U8_U16". The table length is 64. This start address must be
 *                            8-byte aligned.
 * [out]  pSrcDst       To achieve better performance, the output 8x8 matrix is the transpose of the explicit result.
 *                      This transpose will be handled in Huffman encoding.
 *                      Each 8x8 block in the buffer is stored as 64 entries (16-bit) linearly in a buffer,
 *                      and the multiple blocks to be processed must be adjacent.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxICJP_DCTQuantFwd_Multiple_S16_I_DLx (
     OMX_S16* pSrcDst,
     OMX_INT nBlocks,
     const OMX_U16 *pQuantFwdTable
 );
/**
 * Function: omxICJP_DCTQuantInv_Multiple_S16_I_DLx
 *
 * Brief:
 * In-place, multiple block dequantization and IDCT function.
 *
 * Description:
 * This function implements inverse DCT with dequantization for 8-bit image data. It processes multiple
 * blocks (each 8x8).The blocks are assumed to be part of a planarized buffer.
 * This function needs to be called separately for luma and chroma buffers with the respective quantization table.
 * The start address of pQuantRawTable and pQuantInvTable must be 8-byte aligned.
 *
 *
 * Parameters:
 * [in]  pSrcDst    Identifies input coefficient block(8x8) buffer for in-place processing.
 *                      The start address must be 8-byte aligned.
 * [in]    nBlocks        the number of 8x8 blocks to be processed.
 * [in]    pQuantInvTable identifies the quantization table which was generated from
 *                            "DCTQuantInvTableInit_JPEG_U8_U16". The table length is 64 entries by 16-bit. The start address must be
 *                            8-byte aligned.
 *
 * [out]  pSrcDst    Identifies output coefficient block(8x8).
 *                      The start address must be 8-byte aligned.
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxICJP_DCTQuantInv_Multiple_S16_I_DLx(
     OMX_S16* pSrcDst,
     OMX_INT nBlocks,
     const OMX_U16 *pQuantInvTable
 );


/**
 * EndDomain: JP
 */

/* **************************************************************************************** */
/**
 *
 *  NewDomain: JP2K The JPEG 2000 Image Codec Subdomain
 *  WithinDomain: IC
 *
 *	JP2K is designed to support image CODECs that are compliant with ISO/IEC 15444-1.
 *  For both of forward discrete wavelet transformation (FDWT) and inverse discrete wavelet
 *  transformation (IDWT), JPEG 2000 standard specifies two kinds of transformations: one uses a
 *  5-3 reversible filter and the other applies a 9-7 irreversible filter.
 *
 *  StartDomain: JP2K
 */
/* **************************************************************************************** */


/**
 * Function:omxICJP2K_WTGetBufSize_B53_S16_C1IR_DLx
 * Description:
 * Get the buffer size (in bytes) for both one-level 2D forward and inverse wavelet transformation on
 * an image tile (of 16-bit data) using 5-3 reversible filter.
 * Parameters:
 * [in]  pTileRect       pointer to an OMXRect data structure, which indicates the position and size of the
 *                       image tile
 * [out] pSize           pointer to an integer of size of the internal buffer used by 2D 5-3 wavelet transformation
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTGetBufSize_B53_S16_C1IR_DLx(
	const OMXRect *pTileRect,
    OMX_INT *pSize
);


/**
 * Function:omxICJP2K_WTGetBufSize_B53_S32_C1IR_DLx
 * Description:
 * Get the buffer size (in bytes) for both one-level 2D forward and inverse wavelet transformation on
 * an image tile (of 32-bit data) using 5-3 reversible filter.
 * Parameters:
 * [in]  pTileRect   pointer to an OMXRect data structure, which indicates the position and size of the
 *                image tile
 * [out] pSize      pointer to an integer of size of the internal buffer used by 2D 5-3 wavelet transformation 
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */

OMXResult omxICJP2K_WTGetBufSize_B53_S32_C1IR_DLx(
	const OMXRect *pTileRect,
    OMX_INT *pSize
);

/**
 * Function:omxICJP2K_WTFwd_B53_S16_C1IR_DLx
 * Description:
 * This function makes a one-level forward 2D wavelet transformation on one image tile using the
 * 5-3 reversible filter. The DWT coefficients are de-interleaved into LL, HL, LH and HH subbands
 * and written back to the buffer of input data. The image tile data are in 16-bit data type.
 * Parameters:
 * [in]  pSrcDstTile    pointer to the buffer of input image tile. The start address of pSrcDstTile
                     must be 8-byte aligned. It is better to make it 32-byte aligned.
 * [in]  step           specifies the number of bytes in a line of the input data buffer. step is in bytes, and
                     must be an integer multiple of 8.
 * [in]  pTileRect      pointer to an OMXRect data structure, which indicates the position and size of
                     the image tile
 * [in]  pBuffer        pointer to the work buffer for transform.The start address of pBuffer must be
                     8-byte aligned. It is better to make it 32-byte aligned.
                     The work buffer pointed by pBuffer must be allocated before the function is called, and its
                     size can be gotten by calling "ICJP2K_WTGetBufSize_B53_S16_C1IR".
 * [out] pSrcDstTile   pointer to the buffer of output DWT coefficients
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTFwd_B53_S16_C1IR_DLx(
					   OMX_S16 *pSrcDstTile,
                       OMX_INT step, 
					   const OMXRect *pTileRect,
					   OMX_U8 *pBuffer
);

/**
 * Function:omxICJP2K_WTFwd_B53_S32_C1IR_DLx
 * Description
 * This function makes a one-level forward 2D wavelet transformation on one image tile using the
 * 5-3 reversible filter. The DWT coefficients are de-interleaved into LL, HL, LH and HH subbands
 * and written back to the buffer of input data. The image tile data are in 32-bit data type.
 * Parameters:
 * [in]  pSrcDstTile     pointer to the buffer of input image tile. The start address of pSrcDstTile
                      must be 8-byte aligned. It is better to make it 32-byte aligned.
 * [in]  step            specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                    must be an integer multiple of 8.
 * [in]  pTileRect       pointer to an OMXRect data structure, which indicates the position and size of
 *                    the image tile
 * [in]  pBuffer         pointer to the work buffer for transform. The start address of pBuffer must be
 *                    8-byte aligned. It is better to make it 32-byte aligned.
 *                    The work buffer pointed by pBuffer must be allocated before the function is called, and its
 *                    size can be gotten by calling "ICJP2K_WTGetBufSize_B53_S32_C1IR".
 * [out] pSrcDstTile    pointer to the buffer of output DWT coefficients.
 * NOTE:
 * The input image tile can be either one tile-component of the image or
 * the LL subband of the higher level's DWT coefficients. The DWT results are
 * de-interleaved into 4 subbands, which are written to the buffer pointed by
 * pSrcDstTile.
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTFwd_B53_S32_C1IR_DLx(
							OMX_S32 *pSrcDstTile,
							OMX_INT step,
                            const OMXRect *pTileRect,
							OMX_U8 *pBuffer);

/**
 * Function:omxICJP2K_WTInv_B53_S16_C1IR_DLx
 * Description:
 * This function interleaves the LL, HL, LH and HH subbands of DWT coefficients and then makes
 * a one-level inverse 2D wavelet transformation on them using the 5-3 reversible filter. The results
 * are written back to the buffer of input data. The image tile data are in 16-bit data type.
 * Parameters:
 * [in]  pSrcDstTile   pointer to the buffer of input LL, HL, LH and HH subbands of DWT
 *                  coefficients. The start address of pSrcDstTile must be 8-byte aligned. It is better to make it
 *                  32-byte aligned.
 * [in]  step         specifies the number of bytes in a line of the input data buffer. step is in bytes, and
                   must be an integer multiple of 8.
 * [in]  pTileRect    pointer to an OMXRect data structure which indicates the position and size of
                   the image tile.
 * [in]  pBuffer      pointer to the work buffer for transform. The start address of pBuffer must be
 *                 8-byte aligned. It is better to make it 32-byte aligned.
 *                 The work buffer pointed by pBuffer must be allocated before the function is called, and its
 *                 size can be gotten by calling "ICJP2K_WTGetBufSize_B53_S16_C1IR"
 * [out] pSrcDstTile pointer to the buffer of output image tile
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTInv_B53_S16_C1IR_DLx(
						OMX_S16 *pSrcDstTile,
                        OMX_INT step, 
						const OMXRect *pTileRect,
						OMX_U8 *pBuffer
);


/**
 * Function:omxICJP2K_WTInv_B53_S32_C1IR_DLx
 *
 * Description:
 * This function interleaves the LL, HL, LH and HH subbands of DWT coefficients and then makes
 * a one-level inverse 2D wavelet transformation on them using the 5-3 reversible filter. The results
 * are written back to the buffer of input data. The image tile data are in 32-bit data type.
 * Parameters:
 * [in]  pSrcDstTile    pointer to the buffer of input LL, HL, LH and HH subbands of DWT
 *                   coefficients. The start address of pSrcDstTile must be 8-byte aligned. It is better to make it
 *                   32-byte aligned.
 * [in]  step           specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                   must be an integer multiple of 8.
 * [in]  pTileRect      pointer to an OMXRect data structure which indicates the position and size of
 *                   the image tile
 * [in]  pBuffer        pointer to the work buffer for transform. The start address of pBuffer must be
 *                   8-byte aligned. It is better to make it 32-byte aligned.
 *                   The work buffer pointed by pBuffer must be allocated before the function is called, and its
 *                   size can be gotten by calling "ICJP2K_WTGetBufSize_B53_S32_C1IR".
 * [out] pSrcDstTile   pointer to the buffer of output image tile
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */

OMXResult omxICJP2K_WTInv_B53_S32_C1IR_DLx(
						OMX_S32 *pSrcDstTile, 
						OMX_INT step,
                        const OMXRect *pTileRect,
						OMX_U8 *pBuffer
);

/**
 * Function:omxICJP2K_WTGetBufSize_D97_S16_C1IR_DLx
 *
 * Description:
 * Get the buffer size (in bytes) for both one-level 2D forward and inverse wavelet transformation on
 * an image tile (of 16-bit data) using 9-7 reversible filter.
 * Parameters:
 * [in]  pTileRect   pointer to an OMXRect data structure, which indicates the position and size of the
 *                   image tile
 * [out] pSize         pointer to an integer of size of the internal buffer used by 2D 9-7 wavelet transformation.
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTGetBufSize_D97_S16_C1IR_DLx(
	const OMXRect *pTileRect,
    OMX_INT *pSize
);


/**
 * Function:omxICJP2K_WTGetBufSize_D97_S32_C1IR_DLx
 *
 *
 * Description:
 * Get the buffer size (in bytes) for both one-level 2D forward and inverse wavelet transformation on
 * an image tile (of 32-bit data) using 9-7 reversible filter.
 * Parameters:
 * [in]  pTileRect  pointer to an OMXRect data structure, which indicates the position and size of the
                 image tile
 * [out] pSize     pointer to an integer of size of the internal buffer used by 2D 9-7 wavelet transformation
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTGetBufSize_D97_S32_C1IR_DLx(
	const OMXRect *pTileRect,
    OMX_INT *pSize
);


/**
 * Function:omxICJP2K_WTFwd_D97_S16_C1IR_DLx
 *
 * Description
 * This function makes a fix-point implementation of one-level forward 2D wavelet transformation
 * on one image tile using the 9-7 irreversible filter. The DWT coefficients are de-interleaved into
 * LL, HL, LH and HH subbands and written back to the buffer of input data. The image tile data are
 * in 16-bit data type.
 * Parameters:
 * [in]  pSrcDstTile   pointer to the buffer of input image tile. The start address of pSrcDstTile
 *                  must be 8-byte aligned. It is better to make it 32-byte aligned.
 * [in]  step          specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                  must be an integer multiple of 8.
 * [in]  pTileRect     pointer to an OMXRect data structure, which indicates the position and size of
 *                  the image tile
 * [in]  pBuffer       pointer to the work buffer for transform. The start address of pBuffer must be
 *                  8-byte aligned. It is better to make it 32-byte aligned.
 *                  The work buffer pointed by pBuffer must be allocated before the function is called. Its size
 *                  can be gotten by calling "ICJP2K_WTGetBufSize_D97_S16_C1IR"
 * [out] pSrcDstTile  pointer to the buffer of output DWT coefficients
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */

OMXResult omxICJP2K_WTFwd_D97_S16_C1IR_DLx (
							OMX_S16 *pSrcDstTile, 
							OMX_INT step,
                            const OMXRect *pTileRect,
							OMX_U8 *pBuffer
);

/**
 * Function:omxICJP2K_WTFwd_D97_S32_C1IR_DLx
 *
 * Description
 * This function makes a fix-point implementation of one-level forward 2D wavelet transformation
 * on one image tile using the 9-7 irreversible filter. The DWT coefficients are de-interleaved into
 * LL, HL, LH and HH subbands and written back to the buffer of input data. The image tile data are
 * in 32-bit data type.
 * Parameters:
 * [in]  pSrcDstTile   pointer to the buffer of input image tile. The start address of pSrcDstTile
                    must be 8-byte aligned. It is better to make it 32-byte aligned.
 * [in]  step          specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                  must be an integer multiple of 8.
 * [in]  pTileRect     pointer to an OMXRect data structure, which indicates the position and size of
 *                  the image tile
 * [in]  pBuffer       pointer to the work buffer for transform. The start address of pBuffer must be
 *                  8-byte aligned. It is better to make it 32-byte aligned.
 *                  The work buffer pointed by pBuffer must be allocated before the function is called. Its size
 *                  can be gotten by calling "ICJP2K_WTGetBufSize_D97_S32_C1IR"
 * [out] pSrcDstTile  pointer to the buffer of output DWT coefficients.
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */

OMXResult omxICJP2K_WTFwd_D97_S32_C1IR_DLx (
			OMX_S32 *pSrcDstTile,
            OMX_INT step,
			const OMXRect *pTileRect, 
			OMX_U8 *pBuffer
);

/**
 * Function:omxICJP2K_WTInv_D97_S16_C1IR_DLx
 *
 * Description
 * This function interleaves the LL, HL, LH and HH subbands of DWT coefficients and then makes
 * a fix-point implementation of one-level inverse 2D wavelet transformation on them using the 9-7
 * irreversible filter. The results are written back to the buffer of input data. The image tile data are in
 * 16-bit data type.
 * Parameters:
 * [in]  pSrcDstTile   pointer to the buffer of input LL, HL, LH and HH subbands of DWT
 *                  coefficients. The start address of pSrcDstTile must be 8-byte aligned. It is better to make it
 *                  32-byte aligned.
 * [in]  step          specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                  must be an integer multiple of 8.
 * [in]  pTileRect     pointer to an OMXRect data structure which indicates the position and size of
 *                  the image tile
 * [in]  pBuffer       pointer to the work buffer for transform.The start address of pBuffer must be
 *                  8-byte aligned. It is better to make it 32-byte aligned.
 *                  The work buffer pointed by pBuffer must be allocated before the function is called. Its size
 *                  can be gotten by calling "ICJP2K_WTGetBufSize_D97_S16_C1IR".
 * [out] pSrcDstTile  pointer to the buffer of output image tile
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTInv_D97_S16_C1IR_DLx(
					OMX_S16 *pSrcDstTile,
                    OMX_INT step,
					const OMXRect *pTileRect, 
					OMX_U8 *pBuffer
);

/**
 * Function:omxICJP2K_WTInv_D97_S32_C1IR_DLx
 * Description:
 * This function interleaves the LL, HL, LH and HH subbands of DWT coefficients and then makes
 * a fix-point implementation of one-level inverse 2D wavelet transformation on them using the 9-7
 * irreversible filter. The results are written back to the buffer of input data. The image tile data are in
 * 32-bit data type.
 * Parameters:
 * [in]  pSrcDstTile   pointer to the buffer of input LL, HL, LH and HH subbands of DWT
                    coefficients. The start address of pSrcDstTile must be 8-byte aligned. It is better to make it
                    32-byte aligned.
 * [in]  step          specifies the number of bytes in a line of the input data buffer. step is in bytes, and
 *                  must be an integer multiple of 8.
 * [in]  pTileRect     pointer to an OMXRect data structure which indicates the position and size of
 *                  the image tile
 * [in]  pBuffer       pointer to the work buffer for transform. The start address of pBuffer must be
 *                  8-byte aligned. It is better to make it 32-byte aligned.
 *                  The work buffer pointed by pBuffer must be allocated before the function is called. Its size
 *                  can be retrieved by calling "ICJP2K_WTGetBufSize_D97_S32_C1IR".
 * [out] pSrcDstTile  pointer to the buffer of output image tile
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 */
OMXResult omxICJP2K_WTInv_D97_S32_C1IR_DLx (
					OMX_S32 *pSrcDstTile,
                    OMX_INT step,
					const OMXRect *pTileRect, 
					OMX_U8 *pBuffer
);

/**
 * EndDomain: JP2K
 */

/* *****************************************************************************************/
/**
 *
 *	NewDomain: PP The Pre- and Post-processing subdomain
 *  WithinDomain: IP
 *
 *  StartDomain: PP
 */

 /**
 *
 * Function: omxIPPP_Dering_Luma_DLx()
 *
 * Brief:
 * This filter de-rings a region within the luminance plane of an image.
 *
 * Description:
 * The input and output buffers represent the luminance color plane 
 * of an image, 8-bits per pixel.
 *
 * Status: Design
 *
 * Remarks:
 * The output buffer region is required to have the same size as 
 * that of the input region, although the width of the overall 
 * images may differ.
 *
 * Parameters:
 * [in]    pSrc           pointer to the input buffer
 * [in]    roiSize        the dimensions of the input region in pixels
 * [in]    srcStep        step in bytes through the source image
 * [in]    dstStep        step in bytes through the destination image
 * [in]    pQuant         buffer specifying the quantization factor of each 16x16 block (not used if NULL)
 * [out]  pDst           pointer to the output buffer (a single image plane, 8bpp)
 *
 * return value:
 * Standard OMXResult result. See enumeration for possible result codes.
 * 
 */

OMXResult omxIPPP_Dering_Luma_DLx( 
     const OMX_U8       *pSrc,
     const OMXSize	*roiSize,
     const OMX_U32       srcStep,
     const OMX_U32       dstStep, 
     const OMX_S16      *pQuant,
     OMX_U8       *pDst
 );

/**
 *
 * Function: omxIPPP_Dering_Chroma_DLx()
 *
 * Brief:
 * This filter de-rings a region within a chrominance plane of an image.
 *
 * Description:
 * The input and output buffers represent a single chroma color plane 
 * of an image, 8-bits per pixel.
 *
 * Status: Design
 *
 * Remarks:
 * The output buffer region is required to have the same size as 
 * that of the input region, although the width of the overall 
 * images may differ.
 *
 * Inputs:
 * [in]    pSrc           pointer to the input buffer (a single image plane, 8bpp)
 * [in]    roiSize	    the dimensions of the input region in pixels
 * [in]    srcStep        step in bytes through the source image
 * [in]    dstStep        step in bytes through the destination image
 * [in]    pQuant         buffer specifying the quantization factor of each 16x16 block (not used if NULL)
 * [out]  pDst           pointer to the output buffer (a single image plane, 8bpp)
 *
 * return value:
 * Standard OMXResult result. See enumeration for possible result codes.
 * 
 */

OMXResult omxIPPP_Dering_Chroma_DLx( 
     const OMX_U8   *pSrc,
     const OMXSize  *roiSize,
     const OMX_INT   srcStep,
     const OMX_INT   dstStep,
     const OMX_S16  *pQuant,
     OMX_U8   *pDst
 );
/**
 * EndDomain: PP
 */

/* *****************************************************************************************/
/**
 *
 *	NewDomain: CS The Color Space Coversion Subdomain
 *  WithinDomain: IP
 * 
 *  StartDomain: IPCS
 */

/** Gamma table selector for omxIPCS_RGGBtoYCbCr function */
typedef enum
{
	OMX_IPCS_GAMMA_TABLE_COMBINED_DEFAULT	=	0,		/* Combined R+G+B table, default */
	OMX_IPCS_GAMMA_TABLE_COMBINED_EXTERN	=	1,		/* Combined R+G+B table, external */
	OMX_IPCS_GAMMA_TABLE_DISCRETE_DEFAULT	=	2,		/* Discrete R/G/B table, default */
	OMX_IPCS_GAMMA_TABLE_DISCRETE_EXTERN	=	3		/* Discrete R/G/B table, external */
} OMXIPCSGammaTableType;

/** RGGB pixel prcoessing chain configuration 
 * This structure is used to pass setup and configuration parameters to omxIPCS_RGGBtoYCbCrGetBufSize()
 * and omxIPCS_RGGBtoYCbCrInit().
 */
typedef struct
{
    OMX_INT srcStep;						/** Distance, in bytes, between the start of lines
	                                          * in the source image */

	OMXSize srcSize;						/** Dimensions, in pixels, of the source regions
                                              * of interest */

    OMX_INT dstStep[3];                     /** A 3-element vector containing the distance, in
                                              * bytes, between the start of lines in
                                              * each of the output image planes */

    OMXSize dstSize;                        /* Dimensions, in pixels, of the output source
                                             * regions of interest */

    OMXIPInterpolation interpolation;       /** Interpolation method used for CFA
                                              * interpolation and resizing */
    OMXIPRotation rotation;                 /** Rotation control parameter */
    OMXIPColorSpace YCbCrSpec;              /** Color conversion control parameter 
	                                            must be set to one of the following
                                                pre-defined values - OMX_IP_YCbCr422 or 
								                OMX_IP_YCbCr420 */
} OMXIPCSRawPixProcCfg_P3R;

/** RGGB sensor configuration 
 * This structure is used to pass sensor-specific parameters to omxIPCS_RGGBtoYCbCrGetBufSize()
 * and omxIPCS_RGGBtoYCbCrInit().
 */
typedef struct
{
	OMX_INT BitDepth;						/** Bit depth of the input raw data from Sensor.
                                              * Typically 8, 9, or 10 bits */
    OMXIPCSGammaTableType  GammaTableType;  /** Selects gamma table type */
    OMX_INT GammaIndex[3];					/** Indicates the index of predefined gamma tables
                                              * when GammaFlag set to predefined options*/
    OMX_U8 *pGammaTable[3];					/** A 3-element vector containing pointers to
                                              * the external gamma tables for R/G/B respectively when
                                              * GammaFlag set to OMX_IPPP_GAMMA_TABLE_COMBINED_EXTERN or 
                                              * or OMX_IPPP_GAMMA_TABLE_DISCRETE_EXTERN */

    OMX_U32 *pDeadPixMap;					/** Pointer to the start of the absolute Dead
											  * Pixel Map of the sensor array */

    OMX_INT  DPMLen;						/** Length, in pixels, of the Dead Pixel Map */
    OMXPoint DPMOffset;						/** Offset of start position of the cropping
                                              * window, from the (0,0), DPMOffset.x is the row offset
                                              * and DPMOffset.y is the column offset */
    OMXIPInterpolation DPInterp;			/** Interpolation method used for dead pixel
                                              *substitution */
    OMX_S16 *pCCMatrix;                     /** Color correction Matrix */
} OMXIPCSRGGBSensorCfg;

/** Raw pixel processing state, vendor-specific */
typedef void OMXIPCSRawPixProcSpec_P3R;

 
/**
 * Function: omxIPCS_RGGBtoYCbCrGetBufSize_DLx
 *
 * Description:
 * Get buffer size for OMXiRawPixProcSpec_P3R structure.
 *
 * Remarks:
 * This function calculate the OMXiRawPixProcSpec_P3R structure size for user.
 *
 *
 * Parameters:
 * [in]    pCAMCfg        pointer to the sensor-specific configuration structure.
 * [in]    pRPPCfg        pointer to the application-specific configuration structure.
 * [out]  pSize          pointer to the varible to hold the structure size.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxIPCS_RGGBtoYCbCrGetBufSize_DLx(
     const OMXIPCSRGGBSensorCfg *pCAMCfg,
     const OMXIPCSRawPixProcCfg_P3R *pRPPCfg,
     OMX_INT *pSize        
 );



/**
 * Function: omxIPCS_RGGBtoYCbCrInit_DLx
 *
 * Description:
 * Initialize raw data processing specification structure.
 *
 * Remarks:
 * This function is used to initialize the raw data processing specification structure.
 * It must be called prior to omxIPCS_RGGBtoYCbCr_RotRsz_U8_P3R().
 *
 *
 * Parameters:
 * [in]    pCAMCfg        pointer to the sensor-specific configuration structure.
 * [in]    pRPPCfg        pointer to the application-specific configuration structure.
 * [in]    pRPPSpec       pointer to the implementation-specific state structure.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxIPCS_RGGBtoYCbCrInit_DLx(
     const OMXIPCSRGGBSensorCfg *pCAMCfg,
     const OMXIPCSRawPixProcCfg_P3R *pRPPCfg,
     OMXIPCSRawPixProcSpec_P3R *pRPPSpec        
 );


/**
 * Function: omxIPCS_RGGBtoYCbCr_RotRsz_U8_P3R_DLx
 *
 * Description:
 * Raw pixel processing function.
 *
 * Remarks:
 * The raw pixel processing functions convert raw RGGB pixel data to YCbCr422/420 planar data
 * using the following sequence of operations: optional dead pixel correction, companding and
 * gamma correction, optional scale reduction, color synthesis, color correction, color conversion,
 * and optional rotation.
 * The color synthesis methodology is a function of the specified resize ratio. Three cases are
 * possible: a) no scale reduction, b) 2:1 scale reduction, or c) 4:1 scale reduction
 * a. No scale reduction
 * Bilinear interpolation is applied. Missing colors are synthesized by averaging the nearest
 * neighbor pixel intensities of the same color, possibly as shown in the figure below.
 * b. 2:1 scale reduction
 * R, G and B values for one output pixel are calculated from values of four adjacent source
 * pixels (2*2 block of RGGB). R and B values are set equal to the values of the nearest red
 * and blue pixels, while G is set equal to the average of the two nearest green pixels,
 * possibly as shown in the figure below.
 * c. 4:1 scale reduction
 * A possible approach is shown in the figure below.
 * The color space conversion is computed as follows:
 * Y = 0.29900 * R + 0.58700 * G + 0.11400 * B
 * Cb = -0.16874 * R - 0.33126 * G + 0.50000 * B + 128
 * Cr = 0.50000 * R - 0.41869 * G - 0.08131 * B + 128
 * The initialization function ippiRGGBtoYCbCrInit() should be called prior to
 * omxiRGGBtoYCbCr_RotRsz_U8_P3R> in order to initialize the raw data processing state structure.
 *
 *
 * Parameters:
 * [in]    pSrc           pointer to the start of the buffer containing the pixel-oriented RGGB input image. The
 *                            input image buffer referenced by pSrc must contain one pixel of padding on all four edges, ie the
 *                            buffer size should be equal to the image height+2 by the image width+2. pSrc should point to the
 *                            start to the ROI but not the start of the padding region.
 * [in]    pRPPSpec       pointer to the implementation-specific state structure.
 * [out]  pDst           a 3-element vector containing pointers to the start of the YCbCr422/YCbCr420 output
 *                            planes.
 *
 * Return Value:
 * Standard OMXResult result. See enumeration for possible result codes.
 *
 */

OMXResult omxIPCS_RGGBtoYCbCr_RotRsz_U8_P3R_DLx(
     OMX_U8 *pSrc,
     OMX_U8 *pDst[3],
     OMXIPCSRawPixProcSpec_P3R *pRPPSpec        
 );

/**
 * EndDomain: CS
 */

#ifdef __cplusplus
}
#endif

#endif /** end of #define _OMXDLx_H_ */

/** EOF */
